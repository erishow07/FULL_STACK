let canvas = document.getElementById('canvas')
let ctx= canvas.getContext('2d');

let ball = {
    x: 0,
    y: 100,
    raio: 50,
    img: new Image(),
    desenhar: function(){
        this.img.src = 'giga.png'
        ctx.beginPath();
        ctx.drawImage(this.img, this.x-ball.raio, this.y-ball.raio, 2*this.raio, 2*this.raio);
        ctx.closePath();
    }
}


function animacao(){
    ctx.clearRect(0,0,300,300)
    ball.desenhar();
    requestAnimationFrame(animacao)
}


addEventListener('mousemove', function(evento){
    rect = canvas.getBoundingClientRect();
    x_mouse = evento.clientX - rect.left,
    y_mouse = evento.clientY - rect.top;
    console.log(x_mouse, y_mouse);
});



animacao();
document.addEventListener('mousemove',function(evento){
    let x_mouse = evento.clientX - rect.left;
    let y_mouse = evento.clientY - rect.top;
    console.log(x_mouse,y_mouse);

    if (x_mouse>0+ball.raio && x_mouse<300-ball.raio && y_mouse>0+ball.raio && y_mouse<300-ball.raio){
        ball.x = x_mouse;
        ball.y = y_mouse;
    }
    else{
        ball.x = ball.x
        ball.y = ball.y
    }
});
