var randomnum = Math.floor(Math.random()*10);
console.log(randomnum);


function Guess(){

    var usernum = document.getElementById("numero").value
    if (usernum == randomnum){
        document.getElementById("bodin").style.setProperty("background-color", "green");
    }
    else{
        document.getElementById("bodin").style.setProperty("background-color", "red");
    }
}